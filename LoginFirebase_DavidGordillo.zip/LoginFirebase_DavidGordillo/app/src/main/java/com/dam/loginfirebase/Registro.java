package com.dam.loginfirebase;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Registro extends AppCompatActivity implements View.OnClickListener {
    // Declaración de variables y views usadas en la actividad "registro".
    EditText name, lastname, user, pass, repass;
    Button signupbutton;

    FirebaseAuth.AuthStateListener authRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        // Creación de las views.
        name = findViewById(R.id.name);
        lastname = findViewById(R.id.lastname);
        user = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        repass = findViewById(R.id.repass);
        signupbutton = findViewById(R.id.sign_up);

        // Asignación del onClickListener al botón de "Sign Up".
        signupbutton.setOnClickListener(this);

        // Función interna que nos monitoriza el estado del usuario.
        authRegistro = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser userFirebase = firebaseAuth.getCurrentUser();
                if (userFirebase != null) {
                    System.out.println("Usuario: " + userFirebase.getEmail() + " registrado");
                } else {
                    System.out.println("El usuario: " + userFirebase.getEmail() + " no se ha podido registrar.");
                }
            }
        };
    }

    // Función para crear usuarios.
    private void registrar(String email, String password) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), "Usuario creado correctamente", Toast.LENGTH_SHORT).show();

                    // Creación del Intent que nos va a llevar a la activity de Login una vez se cree el usuario.
                    Intent intentLogin = new Intent(getApplicationContext(), Login.class);
                    startActivity(intentLogin);

                    // Ponemos los campos vacíos.
                    name.setText("");
                    lastname.setText("");
                    user.setText("");
                    pass.setText("");
                    repass.setText("");

                    finish();

                } else {
                    Toast.makeText(Registro.this, "El usuario no se ha podido crear ", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Función que nos permite crear un usuario si las contraseñas coinciden y volver a la activity "Login".
    @Override
    public void onClick(View v) {

        String email = user.getText().toString();
        String password = pass.getText().toString();

        // Condición para que nos deje registrarnos usuarios solamente si las dos contraseñas introducidas coinciden o notificar a través de un Toast que las pass no coinciden.
        if (repass.getText().toString().equals(pass.getText().toString())) {
            registrar(email, password);

        } else {
            Toast.makeText(this, "Las contraseñas no coincide", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(authRegistro);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (authRegistro != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(authRegistro);
        }
    }
}