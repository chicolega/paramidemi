package com.dam.loginfirebase;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity implements View.OnClickListener {

    // Declaración de variables y views usadas en la actividad "login"
    EditText user, pass;
    Button loginbutton;

    // Asignación del onClickListener al botón de "Sign In".
    FirebaseAuth.AuthStateListener authLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Creación de las views
        user = findViewById(R.id.user);
        pass = findViewById(R.id.pass);
        loginbutton = findViewById(R.id.loginbutton);

        // Asignación del onClickListener al botón de "Sign In".
        loginbutton.setOnClickListener(this);

        // Función interna que nos monitoriza el estado del usuario.
        authLogin = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser userFirebase = firebaseAuth.getCurrentUser();
                if (userFirebase != null) {
                    System.out.println("Sesión iniciada con email: " + userFirebase.getEmail());
                } else {
                    System.out.println("Sesión cerrada");
                }
            }
        };
    }

    // Función que nos permite acceder a la siguiente activity si el usuario está registrado.
    private void iniciarSesion(String email, String password) {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Intent intentLogin = new Intent(getApplicationContext(), Loged.class);
                    startActivity(intentLogin);

                } else {
                    Toast.makeText(getApplicationContext(), "Login incorrecto! Inténtalo de nuevo.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Ponemos los campos a vacío para logearnos con otro usuario en caso de que lo deseemos.
        user.setText("");
        pass.setText("");
    }

    // Función onClick que nos permite logearnos con un usuario creado la autentificación de Firebase.
    @Override
    public void onClick(View v) {
        String email = user.getText().toString();
        String password = pass.getText().toString();

        iniciarSesion(email, password);
    }

    // Función onClick que nos permite acceder a la activity "registro" para crear un usuario
    public void registrar(View v) {
        Intent intentRegistro = new Intent(this, Registro.class);
        startActivity(intentRegistro);

        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(authLogin);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (authLogin != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(authLogin);
        }
    }
}
