package com.example.carli.carchat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class StartActivy extends AppCompatActivity {

    //Variables
    Button login, register;

    //FireBase
    FirebaseUser firebaseUser;

    @Override
    protected void onStart() {

        super.onStart();

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        //Para que no inicie con el usuario vacio
        if(firebaseUser!=null){

            Intent intent = new Intent(StartActivy.this, MainActivity.class);
            startActivity(intent);
            finish();

        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_activy);

        //Asosiando las id
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);

        //Evento que lanza el boton de Iniciar Sesion
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StartActivy.this, LoginActivity.class));
            }
        });

        //Evento que lanza el boton de Registrarse
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StartActivy.this, RegisterActivity.class));
            }
        });

    }
}
