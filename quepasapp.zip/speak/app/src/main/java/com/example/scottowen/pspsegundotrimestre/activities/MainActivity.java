package com.example.scottowen.pspsegundotrimestre.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.scottowen.pspsegundotrimestre.Fragments.ChatsFragment;
import com.example.scottowen.pspsegundotrimestre.Fragments.UsersFragment;
import com.example.scottowen.pspsegundotrimestre.Model.Usuario;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * @author Scott Owen
 * @version 08.03.2019
 */
public class MainActivity extends AppCompatActivity {
    /**
     *
     * @param perfil_image;
     *   @param  nameUser;
     *
     *     @param firebaseUser;
     *     @param ref;
     */



    CircleImageView perfil_image;
    TextView nameUser;

    FirebaseUser firebaseUser;
    DatabaseReference ref;

    /**
     * Asigna lo campos en el layout con las variables creadas ademas de implementar los onclicks
     * @param savedInstanceState
     */
    //Asigna lo campos en el layout con las variables creadas ademas de implementar los onclicks
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.scottowen.pspsegundotrimestre.R.layout.activity_main);

        Toolbar toolbar = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");

        perfil_image = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.profile_image);
        nameUser = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.username);

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        ref = FirebaseDatabase.getInstance().getReference("Users").child(firebaseUser.getUid());
        /**
         * Realiza una consulta para localizar la imagen del perfil de usuario
         */
        //
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Usuario usuario = dataSnapshot.getValue(Usuario.class);
                nameUser.setText(usuario.getUsername());

                if(usuario.getImageURL().equals("default")){
                    perfil_image.setImageResource(com.example.scottowen.pspsegundotrimestre.R.mipmap.ic_launcher);
                } else {
                    Glide.with(MainActivity.this).load(usuario.getImageURL()).into(perfil_image);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




        TabLayout tabLayout = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.tab_layout);
        ViewPager viewPager = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.view_pager);

        ViewPageAdapter viewPageAdapter = new ViewPageAdapter(getSupportFragmentManager());

        viewPageAdapter.addFragment(new ChatsFragment(), "Chats");
        viewPageAdapter.addFragment(new UsersFragment(), "Usuarios");

        viewPager.setAdapter(viewPageAdapter);

        tabLayout.setupWithViewPager(viewPager);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(com.example.scottowen.pspsegundotrimestre.R.menu.menu, menu);
        return true;
    }

    /**
     * Cuando pulsas el boton cerrar sesion cierra sesion
     * @param item
     * @return
     */
    //
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case com.example.scottowen.pspsegundotrimestre.R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity.this, StartActivity.class));
                finish();
                return true;
        }
        return false;
    }


    /**
     * Creamos una clase que servira como adaptador para ver el fragment
     */
//
    class ViewPageAdapter extends FragmentPagerAdapter{

        private ArrayList<Fragment> fragments;
        private ArrayList<String> titles;

        ViewPageAdapter(FragmentManager fm){
            super(fm);
            this.fragments = new ArrayList<>();
            this.titles = new ArrayList<>();
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        public void addFragment(Fragment fragment, String title){
            fragments.add(fragment);
            titles.add(title);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }
    }
}
