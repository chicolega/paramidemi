package com.example.scottowen.pspsegundotrimestre.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.scottowen.pspsegundotrimestre.Adapter.MessagesAdapter;
import com.example.scottowen.pspsegundotrimestre.Model.Chat;
import com.example.scottowen.pspsegundotrimestre.Model.Usuario;
import com.example.scottowen.pspsegundotrimestre.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


/**
 * @author Scott Owen
 * @version 08.03.2019
 */
public class MessegesActivity extends AppCompatActivity {
    /**
     * @param imagen_perfil //Creamos un objeto de la clase CircleImageView
     *     @param username //Creamos un objeto de la clase TextView
     *
     *     @param fuser; //Creamos un objeto de la clase FirebaseUser
     *     @param ref; //Creamos un objeto de DatabaseReference
     *
     *     @param btnsend; //Creamos un objeto de la clase ImageButton
     *     @param sendtext; //Creamos un objeto de la clase EditText
     *
     *     @param messagesAdapter;
     *     @param mChat; //Creamos una lista de para almacear objetos de la clase Chat
     *
     *     @param recyclerView; //Creamos un objeto de la clase RecyclerView
     *
     *     @param intent; //Creamos un objeto de la clase Intent
     */

    CircleImageView imagen_perfil; //Creamos un objeto de la clase CircleImageView
    TextView username; //Creamos un objeto de la clase TextView

    FirebaseUser fuser; //Creamos un objeto de la clase FirebaseUser
    DatabaseReference ref; //Creamos un objeto de DatabaseReference

    ImageButton btnsend; //Creamos un objeto de la clase ImageButton
    EditText sendtext; //Creamos un objeto de la clase EditText

    MessagesAdapter messagesAdapter;
    List<Chat> mChat; //Creamos una lista de para almacear objetos de la clase Chat

    RecyclerView recyclerView; //Creamos un objeto de la clase RecyclerView

    Intent intent; //Creamos un objeto de la clase Intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        recyclerView = findViewById(R.id.reclycler_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        imagen_perfil = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.profile_image);
        username = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.username);
        btnsend = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.btn_send);
        sendtext = findViewById(com.example.scottowen.pspsegundotrimestre.R.id.text_send);

        intent = getIntent();
        final String userid = intent.getStringExtra("userid");
        fuser = FirebaseAuth.getInstance().getCurrentUser();

        /**
         * Al pulsar el boton llama a la funcion enviar mensaje
         */
        //
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = sendtext.getText().toString();



                if(!msg.equals("")){
                    sendmessage(fuser.getUid(), userid, msg);
                } else {
                    Toast.makeText(MessegesActivity.this, "No se puede enviar un mensaje vacío", Toast.LENGTH_SHORT).show();
                }
                sendtext.setText("");
            }
        });
        /**
         * Hace una consulta para conseguir los datos del usuario y mostralo
         */
        //
        ref = FirebaseDatabase.getInstance().getReference("Users").child(userid);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Usuario usuario =  dataSnapshot.getValue(Usuario.class);
                username.setText(usuario.getUsername());

                if(usuario.getImageURL().equals("default")){
                    imagen_perfil.setImageResource(com.example.scottowen.pspsegundotrimestre.R.mipmap.ic_launcher);
                } else {
                    Glide.with(MessegesActivity.this).load(usuario.getImageURL()).into(imagen_perfil);
                }

                readmsn(fuser.getUid(), userid, usuario.getImageURL());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    /**
     * Metodo que sube a la base de datos el mensaje enviado
     * @param sender
     * @param receiver
     * @param message
     */

//

    private void sendmessage(String sender, String receiver, String message){

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();



        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender", sender);
        hashMap.put("receiver", receiver);
        hashMap.put("message", message);

        reference.child("Chats").push().setValue(hashMap);

    }

    /**
     * Metodo que a traves de una consulta llama a la base de datos para coger el mensaje
     * @param myid
     * @param userid
     * @param imageurl
     */

    //
    private void readmsn(final String myid, final String userid, final String imageurl){

        mChat = new ArrayList<>();

        ref = FirebaseDatabase.getInstance().getReference("Chats");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mChat.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Chat chat = snapshot.getValue(Chat.class);

                    if(chat.getReceiver().equals(myid) && chat.getSender().equals(userid) ||
                            chat.getReceiver().equals(userid) && chat.getSender().equals(myid)){
                        mChat.add(chat);
                    }

                    messagesAdapter = new MessagesAdapter(MessegesActivity.this, mChat, imageurl);
                    recyclerView.setAdapter(messagesAdapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
