package com.example.scottowen.pspsegundotrimestre.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.scottowen.pspsegundotrimestre.Model.Chat;
import com.example.scottowen.pspsegundotrimestre.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

/**
 * @author Scott Owen
 * @version 08.03.2019
 */


public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.ViewHolder>{
    /**
     * @param MENSAJE_IZQUIERDA
     *   @param MENSAJE_DERECHA
     */

    public static final int MENSAJE_IZQUIERDA = 0;
    public static final int MENSAJE_DERECHA = 1;

    private Context mContext; //Creamos mContext de la clase Context
    private List<Chat> mChat; //Creamos una lista de la clase Chat
    private String imageURL; //Creamos un string llamado imagenurl

    FirebaseUser fuser; //Creamos un objeto de la clase FirebaseUser


    /**
     *
     * @param mContext
     * @param mChat
     * @param imageURL
     */
    //Creamos un constructor
    public MessagesAdapter(Context mContext, List<Chat> mChat, String imageURL){
        /**
         * Creamos un constructor
         */
        this.mChat = mChat;
        this.mContext = mContext;
        this.imageURL = imageURL;

    }


    /**
     *
     * @param parent
     * @param viewType
     * @return
     * Inflamos el view en onCreateViewHolder
     */
    //Inflamos el view en onCreateViewHolder

    @NonNull
    @Override
    public MessagesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if(viewType == MENSAJE_DERECHA){
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right, parent, false );
            return new MessagesAdapter.ViewHolder(view);
        } else {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left, parent, false );
            return new MessagesAdapter.ViewHolder(view);
        }

    }

    /**
     *
     * @param holder
     * @param position
     * Aqui añadiremos la imagen a cada recyclerview
     */
    //Aqui añadiremos la imagen a cada recyclerview

    @Override
    public void onBindViewHolder(@NonNull MessagesAdapter.ViewHolder holder, int position) {

        Chat chat = mChat.get(position);

        holder.show_message.setText(chat.getMessage());

        if(imageURL.equals("default")){
            holder.profile_image.setImageResource(R.mipmap.ic_launcher);
        } else {
            Glide.with(mContext).load(imageURL).into(holder.profile_image);
        }
    }

    /**
     * En este método devolvemos el tamaño de la lista de usuarios.
     * @return
     */
    //En este método devolvemos el tamaño de la lista de usuarios.
    @Override
    public int getItemCount() {
        return mChat.size();
    }


    /**
     * Aqui asignamos cada TextView e imagen al recyclerview
     */
    //Aqui asignamos cada TextView e imagen al recyclerview
    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView show_message;
        public ImageView profile_image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            show_message = itemView.findViewById(R.id.show_message);
            profile_image = itemView.findViewById(R.id.profile_image);
        }
    }


    @Override
    public int getItemViewType(int position) {
        fuser = FirebaseAuth.getInstance().getCurrentUser();

        if(mChat.get(position).getSender().equals(fuser.getUid())){
            return MENSAJE_DERECHA;
        } else {
            return MENSAJE_IZQUIERDA;
        }

    }
}

