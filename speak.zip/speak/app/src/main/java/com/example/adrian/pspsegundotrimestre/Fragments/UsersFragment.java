package com.example.adrian.pspsegundotrimestre.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.adrian.pspsegundotrimestre.Adapter.UserAdapter;
import com.example.adrian.pspsegundotrimestre.Model.Usuario;
import com.example.adrian.pspsegundotrimestre.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;





public class UsersFragment extends Fragment {

    private RecyclerView recyclerView; //Creamos un objeto de la clase RecyclerView
    public UserAdapter userAdapter;
    private List<Usuario> mUsuarios; //Creamos una lista con objetos de la clase

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_user, container, false);

        recyclerView = view.findViewById(R.id.reclycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mUsuarios = new ArrayList<>();

        leerUsuarios();
        
        return view;
    }



    private void leerUsuarios() {

        final FirebaseUser firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Users");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                mUsuarios.clear();

                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Usuario usuario = snapshot.getValue(Usuario.class);

                    assert usuario != null;
                    assert firebaseUser != null;
                    if(!usuario.getId().equals(firebaseUser.getUid())){
                        mUsuarios.add(usuario);
                    }
                }

                userAdapter = new UserAdapter(getContext(), mUsuarios);
                recyclerView.setAdapter(userAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

}
