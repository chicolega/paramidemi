package com.example.adrian.pspsegundotrimestre.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.adrian.pspsegundotrimestre.Model.Chat;
import com.example.adrian.pspsegundotrimestre.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;




public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.ViewHolder>{




    public static final int MENSAJE_IZQUIERDA = 0; //Explicado en el método getItemViewType()
    public static final int MENSAJE_DERECHA = 1;  //Explicado en el método getItemViewType()

    private Context mContext; //Creamos el objeto mContext de la clase abstracta Context
    private List<Chat> mChat; //Creamos una lista de la clase Chat
    private String imagenURL; //Creamos un string llamado imagenurl

    FirebaseUser fuser; //Creamos un objeto de la clase FirebaseUser




    public MessagesAdapter(Context mContext, List<Chat> mChat, String imagenURL){
        this.mChat = mChat;
        this.mContext = mContext;
        this.imagenURL = imagenURL;

    }





    @NonNull
    @Override
    public MessagesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if(viewType == MENSAJE_DERECHA){
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right, parent, false );
            return new MessagesAdapter.ViewHolder(view);
        } else {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left, parent, false );
            return new MessagesAdapter.ViewHolder(view);
        }

    }




    @Override
    public void onBindViewHolder(@NonNull MessagesAdapter.ViewHolder holder, int position) {

        Chat chat = mChat.get(position);

        holder.show_message.setText(chat.getMessage());

        if(imagenURL.equals("default")){
            holder.profile_image.setImageResource(R.mipmap.ic_launcher);
        } else {
            Glide.with(mContext).load(imagenURL).into(holder.profile_image);
        }
    }

    //En este método devolvemos el tamaño de la lista de usuarios.
    @Override
    public int getItemCount() {
        return mChat.size();
    }




    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView show_message;
        public ImageView profile_image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            show_message = itemView.findViewById(R.id.show_message);
            profile_image = itemView.findViewById(R.id.profile_image);
        }
    }




    @Override
    public int getItemViewType(int position) {
        fuser = FirebaseAuth.getInstance().getCurrentUser();

        if(mChat.get(position).getSender().equals(fuser.getUid())){
            return MENSAJE_DERECHA;
        } else {
            return MENSAJE_IZQUIERDA;
        }

    }
}

