package com.example.adrian.pspsegundotrimestre.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.adrian.pspsegundotrimestre.MessegesActivity;
import com.example.adrian.pspsegundotrimestre.Model.Usuario;
import com.example.adrian.pspsegundotrimestre.R;

import java.util.List;







public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder>{




    private Context mContext;  //Creamos el objeto mContext de la clase Context
    private List<Usuario> mUsuarios;  //Creamos el objeto mContext de la clase abstracta Context




    public UserAdapter(Context mContext, List<Usuario> mUsuarios){

        this.mUsuarios = mUsuarios;
        this.mContext = mContext;

    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.user_item, parent, false );
        return new UserAdapter.ViewHolder(view);
    }




    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Usuario usuario = mUsuarios.get(position);
        holder.username.setText(usuario.getUsername());

        if(usuario.getImageURL().equals("default")){
            holder.profile_image.setImageResource(R.mipmap.ic_launcher);
        } else {
            Glide.with(mContext).load(usuario.getImageURL()).into(holder.profile_image);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, MessegesActivity.class);
                intent.putExtra("userid", usuario.getId());
                mContext.startActivity(intent);
            }
        });
    }

    //En este método devolvemos el tamaño de la lista de usuarios.
    @Override
    public int getItemCount() {
        return mUsuarios.size();
    }




    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView username;
        public ImageView profile_image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            username = itemView.findViewById(R.id.username);
            profile_image = itemView.findViewById(R.id.profile_image);
        }
    }

}
