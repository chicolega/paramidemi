package com.example.scottowen.aplicacionthreat;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button primero;

     ProgressBar pbarProgreso;

    private MiTareaAsincrona tarea1;

    Button segundo;

    ProgressBar pbarProgreso2;

    private MiTareaAsincrona tarea2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        primero=findViewById(R.id.btnSinHilos);
        pbarProgreso=findViewById(R.id.pbarProgreso);


        primero.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                tarea1 = new MiTareaAsincrona();
                tarea1.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });


        segundo=findViewById(R.id.btnSinHilos2);
        pbarProgreso2=findViewById(R.id.pbarProgreso2);


        segundo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                tarea2 = new MiTareaAsincrona();
                tarea2.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });


        }






        //Clase asyncrona

    private class MiTareaAsincrona extends AsyncTask<Void, Integer, Boolean> {

        @Override
        protected Boolean doInBackground(Void... params) {

            for(int i=1; i<=10; i++) {
                tareaLarga();

                publishProgress(i*10);

                if(isCancelled())
                    break;
            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            pbarProgreso.setProgress(progreso);
        }

        @Override
        protected void onPreExecute() {
            pbarProgreso.setMax(500);
            pbarProgreso.setProgress(0);
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if(result)
                Toast.makeText(MainActivity.this, "Tarea finalizada!", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onCancelled() {
            Toast.makeText(MainActivity.this, "Tarea cancelada!", Toast.LENGTH_SHORT).show();
        }

        private void tareaLarga()
        {
            try {
                Thread.sleep(1000);
            } catch(InterruptedException e) {}
        }
    }
}
