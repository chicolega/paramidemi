package com.dam.loginfirebase;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import android.view.ViewGroup.LayoutParams;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Chat extends AppCompatActivity  {

    Button enviar;
    EditText mensaje;
    LinearLayout mensajes;
    Boolean exist;
    String condicion;

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Chats");

    SimpleDateFormat formatter=new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Bundle extra = getIntent().getExtras();
        String mailDestinatario = extra.getString("Destinatario");
        String mailorigen=extra.getString("Origen");
        String[] mailparts = mailDestinatario.split("@");
        final String destinatarioParts = mailparts[0];
        String[] mailorigenparts = mailorigen.split("@");
        final String origenParts = mailorigenparts[0];

        mensaje=findViewById(R.id.escribe);
        enviar=findViewById(R.id.send);

        mensajes=findViewById(R.id.mensajes);

        nombreChat(origenParts,destinatarioParts);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date fecha = new Date();
                ref.child(condicion).child(origenParts).setValue(mensaje.getText().toString());
                ref.child(condicion).child(origenParts+"Fecha").setValue("Enviado:"+fecha);
                mensaje.setText("");

            }
        });
    }

    public String nombreChat (final String origenParts, final String destinatarioParts){
        final DatabaseReference ref=Chat.miBD.getReference("Chats");
        Query contactos=ref.orderByKey();
        contactos.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    System.out.println("VA POR:"+ds.getKey());
                    if(ds.getKey().equals(destinatarioParts+"_"+origenParts)){
                        condicion=destinatarioParts+"_"+origenParts;
                        System.out.println("Comparacion con:"+ds.getKey()+" Y "+destinatarioParts+"_"+origenParts);



                        TextView origen=new TextView(Chat.this);
                        origen.setBackgroundColor(Color.parseColor("#CC2EFA"));
                        origen.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                        origen.setText(ds.child(origenParts).getValue(String.class));

                        TextView destiny=new TextView(Chat.this);
                        destiny.setBackgroundColor(Color.parseColor("#51A8FE"));
                        destiny.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                        destiny.setText(ds.child(destinatarioParts).getValue(String.class));

                        String fechaorigin=ds.child(origenParts+"Fecha").getValue(String.class);
                        try {
                             Date diaorigen=formatter.parse(fechaorigin);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }


                        mensajes.addView(origen);
                        mensajes.addView(destiny);




                    }else if(ds.getKey().equals(origenParts+"_"+destinatarioParts)){
                        condicion=origenParts+"_"+destinatarioParts;
                        System.out.println("Comparacion con ESTO:"+ds.getKey()+" Y "+origenParts+"_"+destinatarioParts);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        return condicion;
    }

}
