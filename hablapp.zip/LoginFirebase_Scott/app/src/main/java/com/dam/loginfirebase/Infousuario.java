package com.dam.loginfirebase;

public class Infousuario {
    String nombreuser;
    String mailuser;

    public Infousuario() {
    }

    public Infousuario(String nombreuser, String mailuser) {
        this.nombreuser = nombreuser;
        this.mailuser = mailuser;
    }

    public String getNombreuser() {
        return nombreuser;
    }

    public void setNombreuser(String nombreuser) {
        this.nombreuser = nombreuser;
    }

    public String getMailuser() {
        return mailuser;
    }

    public void setMailuser(String mailuser) {
        this.mailuser = mailuser;
    }
}
