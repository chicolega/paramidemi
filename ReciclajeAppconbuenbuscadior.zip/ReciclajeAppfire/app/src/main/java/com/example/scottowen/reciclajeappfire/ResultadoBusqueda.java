package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class ResultadoBusqueda extends AppCompatActivity implements Serializable {

    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();

    ArrayList<PuntoReciclaje> listaResultado;
    DatabaseReference ref;

    Adaptador adapterresult;
    RecyclerView recybusqueda;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                finish();
                Intent intent=new Intent(this,Login.class);
                startActivity(intent);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_busqueda);
        recybusqueda=findViewById(R.id.recyclerView2);

        recybusqueda.setLayoutManager(new LinearLayoutManager(this));
        listaResultado=new ArrayList<PuntoReciclaje>();
        Toolbar toolbar=findViewById(R.id.toolbarid);
        setSupportActionBar(toolbar);
        mostrarResultado();


    }

    public void mostrarResultado() {
        Intent intent=getIntent();
        final String provinciaBuscada= (String) getIntent().getSerializableExtra("busquedaProvincia");

        System.out.println("Provinciabuscada"+provinciaBuscada);
        //Aqui realizamos la consulta que nos devolvera los mejores valorados
        ref = miBD.getReference("Datos");
        Query query = ref.orderByChild("Provincia");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaResultado.removeAll(listaResultado);

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);

                    if(querypr.isVerificacion()==true){
                        if(querypr.getProvincia().equals(provinciaBuscada))
                        listaResultado.add(querypr);
                    }


                }
                adapterresult=new Adaptador(ResultadoBusqueda.this,listaResultado);
                recybusqueda.setAdapter(adapterresult);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
