package com.example.scottowen.reciclajeappfire;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Adapter;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Busqueda extends AppCompatActivity implements View.OnClickListener {
    EditText provinciabusqueda,localidadbusqueda,direccionbusqueda,numerobusqueda;
    String provincia,localidad,direccion,numero;

    ArrayList<PuntoReciclaje> listaresultado;

    RecyclerView viewResultado;

    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busqueda);

        provinciabusqueda=findViewById(R.id.provinciatextofiltro);
        localidadbusqueda=findViewById(R.id.localidadtextofiltro);
        direccionbusqueda=findViewById(R.id.textobusquedadireccion);
        numerobusqueda=findViewById(R.id.numerotextofiltro);


    }

    @Override
    public void onClick(View v) {




        switch (v.getId()){

            case R.id.busquedabutton:
                if(!provinciabusqueda.getText().toString().isEmpty()){
                    provincia= provinciabusqueda.getText().toString();
                    localidad=localidadbusqueda.getText().toString();
                    direccion=direccionbusqueda.getText().toString();
                    numero=numerobusqueda.getText().toString();
                    
                    Intent intent = new Intent(this, ResultadoBusqueda.class);
                    intent.putExtra("busquedaProvincia",provincia);

                    startActivity(intent);
                }else{
                    Toast.makeText(this, "Debe rellenar el campo 'Provincia'", Toast.LENGTH_SHORT).show();
                }



                break;
            case R.id.atrasbotonfiltro:
                Intent intent = new Intent(this, Home.class);
               startActivity(intent);
                break;

        }
    }
}
