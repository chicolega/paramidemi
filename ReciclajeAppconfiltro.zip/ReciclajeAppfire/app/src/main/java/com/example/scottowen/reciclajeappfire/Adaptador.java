package com.example.scottowen.reciclajeappfire;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder> {

    Context context;
    ArrayList<PuntoReciclaje> puntoactual;

    public Adaptador(Context c, ArrayList<PuntoReciclaje>p){
        context =c;
        puntoactual=p;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {


        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.fichacontenedoreslista,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

        myViewHolder.direccion.setText("Direccion:"+puntoactual.get(i).getDireccion());
        myViewHolder.localidad.setText("Localidad:"+puntoactual.get(i).getLocalidad());
        myViewHolder.provincia.setText("Provincia:"+puntoactual.get(i).getProvincia());
        myViewHolder.numero.setText("Numero:"+puntoactual.get(i).getNumero());

        mostrarContenedores(myViewHolder,i);

        String url = puntoactual.get(i).getImagen();
        Picasso
                .with(context)
                .load(url)
                .resize(250, 250)
                .centerCrop()
                .placeholder(R.drawable.reciclapp)
                .into(myViewHolder.imagen);
    }

    @Override
    public int getItemCount() {
        return  puntoactual.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView direccion;
        TextView numero;
        TextView provincia;
        TextView localidad;
        ImageView imagen,conblue,converde,conamar,conblanc,connara,congris;



        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            direccion=itemView.findViewById(R.id.direccionficha);
            numero=itemView.findViewById(R.id.numeroficha);
            provincia=itemView.findViewById(R.id.provinciaficha);
            localidad=itemView.findViewById(R.id.localidadficha);
            imagen = itemView.findViewById(R.id.imagencontenedorficha);
            conblue=itemView.findViewById(R.id.contenedorfichaazul);
            conamar=itemView.findViewById(R.id.contenedorfichaamarill);
            conblanc=itemView.findViewById(R.id.contenedorfichapunt);
            converde=itemView.findViewById(R.id.contenedorfichaverde);
            connara=itemView.findViewById(R.id.contenedorfichanaranja);
            congris=itemView.findViewById(R.id.contenedorfichaorga);
        }
    }

    public void mostrarContenedores(MyViewHolder myViewHolder,int i){
        if(puntoactual.get(i).isContenedorAzul()==true){
            myViewHolder.conblue.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedordebasurap));
        }
        if(puntoactual.get(i).isContenedorAmarillo()==true){
            myViewHolder.conamar.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedordebasurapl));
        }
        if(puntoactual.get(i).isContenedorVerde()==true){
            myViewHolder.converde.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedordebasurav));
        }
        if(puntoactual.get(i).isContenedorNaranja()==true){
            myViewHolder.connara.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedordebasuraac));
        }
        if(puntoactual.get(i).isContenedorGris()==true){
            myViewHolder.congris.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedordebasura));
        }
        if(puntoactual.get(i).isPuntoLimpio()==true){
            myViewHolder.conblanc.setImageDrawable(context.getResources().getDrawable(R.drawable.contenedorpuntolimpio));
        }
    }
}
