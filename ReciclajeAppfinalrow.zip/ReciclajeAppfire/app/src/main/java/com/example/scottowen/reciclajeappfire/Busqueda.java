package com.example.scottowen.reciclajeappfire;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Busqueda extends AppCompatActivity implements View.OnClickListener {
    EditText provinciabusqueda,localidadbusqueda,direccionbusqueda,numerobusqueda;
    String provincia,localidad,direccion,numero;

    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busqueda);

        provinciabusqueda=findViewById(R.id.provinciatextofiltro);
        localidadbusqueda=findViewById(R.id.localidadtextofiltro);
        direccionbusqueda=findViewById(R.id.textobusquedadireccion);
        numerobusqueda=findViewById(R.id.numerotextofiltro);
    }

    @Override
    public void onClick(View v) {
       provincia= provinciabusqueda.getText().toString();
       localidad=localidadbusqueda.getText().toString();
       direccion=direccionbusqueda.getText().toString();
       numero=numerobusqueda.getText().toString();
        switch (v.getId()){

            case R.id.busquedabutton:
                busquedaExacta(provincia,localidad,direccion);
                break;
            case R.id.atrasbotonfiltro:
               Intent intent = new Intent(this, Home.class);
               startActivity(intent);
                break;

        }
    }

    private void busquedaExacta(String provincia, final String localidad,final String direccion){
        ref = miBD.getReference("Datos");
        Query query = ref.orderByChild("provincia").equalTo(provincia);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    PuntoReciclaje pr=ds.getValue(PuntoReciclaje.class);
                    if(pr.getLocalidad().equals(localidad)){
                        if(pr.getDireccion().equals(direccion)){
                            if(pr.getNumero().equals(numero)){
                                dialogResultado(pr.getProvincia(),pr.getLocalidad(),pr.getDireccion(),pr.getNumero());
                            }
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void dialogResultado(String provincia, String localidad,String direccion,String numero) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle( "Resultado busqueda")
                .setMessage("Provincia:"+provincia+"Localidad"+localidad+"Direccion"+direccion+"Numero"+numero)
                .setIcon(R.drawable.contenedorplastico)
                .setCancelable(false) // Condición para que no se pueda ocultar el Dialog sin darle a ningún botón

                // Botón "YES!" del Dialog
                .setPositiveButton("Volver a buscar",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // Aquí va lo que quieres que haga al darle al boton de "YES"

                            }
                        })
                // Botón "Salir" que nos lleva a la pagina de busqueda nuevamente.
                .setNeutralButton("Mapa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setNegativeButton("Cerrar",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent= new Intent(Busqueda.this,Home.class);
                        startActivity(intent);
                        finish();
                    }
                });
        // Código que nos crea y muestra el Dialog.
        builder.create().show();
    }
}
