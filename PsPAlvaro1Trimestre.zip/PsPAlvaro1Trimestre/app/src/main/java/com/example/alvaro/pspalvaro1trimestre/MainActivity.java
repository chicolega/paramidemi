package com.example.alvaro.pspalvaro1trimestre;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button boton1;
    private Button boton2;
    private Button boton3;
    private Button boton4;
    private ProgressBar barra1;
    private ProgressBar barra2;
    private ProgressBar barra3;
    private ProgressBar barra4;

    private miTarea1 tarea1;
    private miTarea2 tarea2;
    private miTarea3 tarea3;
    private miTarea4 tarea4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boton1 = (Button) findViewById(R.id.button);
        boton2 = (Button) findViewById(R.id.button2);
        boton3 = (Button) findViewById(R.id.button3);
        boton4 = (Button) findViewById(R.id.button4);
        barra1 = (ProgressBar) findViewById(R.id.progressBar);
        barra2 = (ProgressBar) findViewById(R.id.progressBar2);
        barra3 = (ProgressBar) findViewById(R.id.progressBar3);
        barra4 = (ProgressBar) findViewById(R.id.progressBar4);

        barra1.setMax(500);
        barra2.setMax(1000);
        barra3.setMax(10000);
        barra4.setMax(25000);


        boton1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                tarea1 = new miTarea1();
                tarea1.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

        boton2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                tarea2 = new miTarea2();
                tarea2.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

        boton3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                tarea3 = new miTarea3();
                tarea3.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

        boton4.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                tarea4 = new miTarea4();
                tarea4.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            }
        });

    }

    private void tareaLarga()
    {
        try {
            Thread.sleep(1);
        } catch(InterruptedException e) {}
    }

    private class miTarea1 extends AsyncTask<Void, Integer, Boolean>{

        @Override
        protected Boolean doInBackground(Void... params) {

            for(int i=1; i<=barra1.getMax(); i++) {

                tareaLarga();

                publishProgress(i*1);

            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            barra1.setProgress(progreso);
        }


        @Override
        protected void onPostExecute(Boolean result) {
            if(result)
                Toast.makeText(MainActivity.this, "Tarea 1 finalizada!", Toast.LENGTH_SHORT).show();
        }

    }

    private class miTarea2 extends AsyncTask<Void, Integer, Boolean>{

        @Override
        protected Boolean doInBackground(Void... params) {

            for(int i=1; i<=barra2.getMax(); i++) {

                tareaLarga();

                publishProgress(i*1);

            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            barra2.setProgress(progreso);
        }


        @Override
        protected void onPostExecute(Boolean result) {
            if(result)
                Toast.makeText(MainActivity.this, "Tarea 2 finalizada!", Toast.LENGTH_SHORT).show();
        }

    }

    private class miTarea3 extends AsyncTask<Void, Integer, Boolean>{

        @Override
        protected Boolean doInBackground(Void... params) {

            for(int i=1; i<=barra3.getMax(); i++) {

                tareaLarga();

                publishProgress(i*1);

            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            barra3.setProgress(progreso);
        }


        @Override
        protected void onPostExecute(Boolean result) {
            if(result)
                Toast.makeText(MainActivity.this, "Tarea 3 finalizada!", Toast.LENGTH_SHORT).show();
        }

    }

    private class miTarea4 extends AsyncTask<Void, Integer, Boolean>{

        @Override
        protected Boolean doInBackground(Void... params) {

            for(int i=1; i<=barra4.getMax(); i++) {

                tareaLarga();

                publishProgress(i*1);

            }

            return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progreso = values[0].intValue();

            barra4.setProgress(progreso);
        }


        @Override
        protected void onPostExecute(Boolean result) {
            if(result)
                Toast.makeText(MainActivity.this, "Tarea 4 finalizada!", Toast.LENGTH_SHORT).show();
        }

    }

}
