package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class ResultadoBusqueda extends AppCompatActivity implements Serializable {

    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();

    ArrayList<PuntoReciclaje> listaResultado;
    DatabaseReference ref;

    Adaptador adapterresult;
    RecyclerView recybusqueda;

    Button reBuscar,backHome,mapaBuscar;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                finish();
                Intent intent=new Intent(this,Login.class);
                startActivity(intent);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_busqueda);
        recybusqueda=findViewById(R.id.recyclerView2);

        reBuscar=findViewById(R.id.volverBuscar);
        backHome=findViewById(R.id.volverHome);
        mapaBuscar=findViewById(R.id.mapaResultado);

        recybusqueda.setLayoutManager(new LinearLayoutManager(this));
        listaResultado=new ArrayList<PuntoReciclaje>();
        Toolbar toolbar=findViewById(R.id.toolbarid);
        setSupportActionBar(toolbar);
        mostrarResultado();

        reBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent (ResultadoBusqueda.this,Busqueda.class);
                startActivity(intent);
            }
        });


    }

    public void mostrarResultado() {
        Intent intent=getIntent();
        final String provinciaBuscada= (String) getIntent().getSerializableExtra("busquedaProvincia");
        final String localidadBuscada=(String) getIntent().getSerializableExtra("busquedaLocalidad");
        final String direccionBuscada=(String) getIntent().getSerializableExtra("busquedaDireccion");
        final String numeroBuscada=(String) getIntent().getSerializableExtra("busquedaNumero");

        final boolean contazul=(boolean)getIntent().getSerializableExtra("cPapel");
        final boolean contverde=(boolean)getIntent().getSerializableExtra("cVidrio");
        final boolean contamarillo=(boolean)getIntent().getSerializableExtra("cPlastico");
        final boolean contblanco=(boolean)getIntent().getSerializableExtra("cPuntolimpio");
        final boolean contgris=(boolean)getIntent().getSerializableExtra("cOrganico");
        final boolean contnaranja=(boolean)getIntent().getSerializableExtra("cAceite");


        //Aqui realizamos la consulta que nos devolvera los mejores valorados
        ref = miBD.getReference("Datos");
        Query query = ref.orderByChild("Provincia");
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaResultado.removeAll(listaResultado);

                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);

                    if(querypr.isVerificacion()==true){
                        //Si todos los campos estan rellenos busca exacta
                        if(querypr.getProvincia().equals(provinciaBuscada)){

                            // Busca exacta con todos los campos
                            if(!localidadBuscada.isEmpty() && querypr.getLocalidad().equals(localidadBuscada)
                                    && !direccionBuscada.isEmpty() && querypr.getDireccion().equals(direccionBuscada)
                            && !numeroBuscada.isEmpty() && querypr.getNumero().equals(numeroBuscada) ){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }



                            //Si todos los campos estan rellenos excepto el campo localidad
                            if(localidadBuscada.isEmpty()
                                    && !direccionBuscada.isEmpty() && querypr.getDireccion().equals(direccionBuscada)
                                    && !numeroBuscada.isEmpty() && querypr.getNumero().equals(numeroBuscada) ){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }




                            // Si todos los campos estan rellenos excepto Direccion.
                            if(!localidadBuscada.isEmpty() && querypr.getLocalidad().equals(localidadBuscada)
                                    && direccionBuscada.isEmpty()
                                    && !numeroBuscada.isEmpty() && querypr.getNumero().equals(numeroBuscada) ){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }




                            //Si todos los campos estan rellenos excepto numero
                            if(!localidadBuscada.isEmpty() && querypr.getLocalidad().equals(localidadBuscada)
                                    && !direccionBuscada.isEmpty() && querypr.getDireccion().equals(direccionBuscada)
                                    && numeroBuscada.isEmpty()){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }




                            //Si todos los campos estan vacios excepto localidad
                            if(!localidadBuscada.isEmpty() && querypr.getLocalidad().equals(localidadBuscada)
                                    && direccionBuscada.isEmpty()
                                    && numeroBuscada.isEmpty()){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }




                            //Si todos los campos estan vacios excepto direccion
                            if(localidadBuscada.isEmpty()
                                    && !direccionBuscada.isEmpty() && querypr.getDireccion().equals(direccionBuscada)
                                    && numeroBuscada.isEmpty()){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }




                            //Si todos los campos estan vacios excepto numero
                            if(localidadBuscada.isEmpty()
                                    && direccionBuscada.isEmpty()
                                    && !numeroBuscada.isEmpty() && querypr.getNumero().equals(numeroBuscada) ){
                                if(contazul==true && contazul==querypr.isContenedorAzul()
                                        || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                        || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                        || contverde==true && contverde==querypr.isContenedorVerde()
                                        || contgris==true && contgris==querypr.isContenedorGris()
                                        || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                    listaResultado.add(querypr);
                                } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                    listaResultado.add(querypr);
                                }
                            }


                            //Si todos los campos estan vacios.
                            if(localidadBuscada.isEmpty()
                                    && direccionBuscada.isEmpty()
                                    && numeroBuscada.isEmpty()){

                                    if(contazul==true && contazul==querypr.isContenedorAzul()
                                            || contnaranja==true && contnaranja==querypr.isContenedorNaranja()
                                            || contamarillo==true && contamarillo==querypr.isContenedorAmarillo()
                                            || contverde==true && contverde==querypr.isContenedorVerde()
                                            || contgris==true && contgris==querypr.isContenedorGris()
                                            || contblanco==true && contblanco==querypr.isPuntoLimpio()){
                                        listaResultado.add(querypr);
                                    } else if(!contazul==true && !contnaranja==true && !contamarillo==true && !contverde==true && !contgris==true && !contblanco==true){
                                        listaResultado.add(querypr);
                                    }

                            }
                        }


                    }


                }
                adapterresult=new Adaptador(ResultadoBusqueda.this,listaResultado);
                recybusqueda.setAdapter(adapterresult);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
