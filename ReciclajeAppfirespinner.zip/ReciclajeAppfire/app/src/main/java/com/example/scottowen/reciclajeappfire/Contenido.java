package com.example.scottowen.reciclajeappfire;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class Contenido extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    /**
     * Java class Home
     * La clase muestra la pagina principal
     * @author Scott Owen
     * @version 1.00, 03 Dec 2018
     */

    EditText provincia, localidad, direccion, numero;
    ImageButton papel, plastico, vidrio, organico, puntolimpio, aceite;
    public static PuntoReciclaje puntoActual;

    Button btnchoose,btoncamera;
    ImageView imagencontenedor;
    ImagenUrl subir;

    private final int PICK_IMAGE_REQUEST=1;

    private static final int CAMERA_REQUEST = 1888;
    private Uri filePath;

    //Creamos las variables para coger la instancia y las referencias de la base de datos del firebase.
    //Almacenamiento de archivos.
    private FirebaseStorage storagebd=FirebaseStorage.getInstance();
    StorageReference storagereference=storagebd.getReference("Contenedores");
    //Almacenamiento de datos en la base de datos.
    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");

    //Asignamos cada campo texto y/o boton a la variable correspondiente.
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contenido);

        puntoActual = new PuntoReciclaje();

        provincia = (EditText) findViewById(R.id.provinciaid);
        
        localidad = (EditText) findViewById(R.id.localidaid);
        direccion = (EditText) findViewById(R.id.direccionid);

        numero = (EditText) findViewById(R.id.numeroid);

        papel=(ImageButton)findViewById(R.id.papelbotoncontenido);
        plastico=(ImageButton)findViewById(R.id.plasticobotoncontenido);
        vidrio=(ImageButton)findViewById(R.id.vidriobotoncontenido);
        organico=(ImageButton)findViewById(R.id.organicobotoncontenido);
        puntolimpio=(ImageButton)findViewById(R.id.puntolimpiobotoncontenido);
        aceite=(ImageButton)findViewById(R.id.aceitebotoncontenido);

        btoncamera=findViewById(R.id.camarabutton);
        btnchoose=findViewById(R.id.choosebutton);

        imagencontenedor=findViewById(R.id.imagenContenedor);


        btoncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        btnchoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        Spinner spinnerprovincia=findViewById(R.id.spinerProvincia);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this,R.array.provincias,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerprovincia.setAdapter(adapter);
        spinnerprovincia.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View v) {

        puntoActual.setProvincia(correccion(provincia.getText().toString()));
        puntoActual.setLocalidad(localidad.getText().toString());
        puntoActual.setDireccion(direccion.getText().toString());
        puntoActual.setNumero(numero.getText().toString());


        //Segun su id hace una u otra accion.
        switch (v.getId()) {

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.papelbotoncontenido:

            if(puntoActual.contenedorAzul == false){
                papel.setBackgroundResource(R.drawable.contenedordebasurapf);
                puntoActual.contenedorAzul = true;
            }else{
                papel.setBackgroundResource(R.drawable.contenedordebasurap);
                puntoActual.contenedorAzul=false;
            }

            break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.plasticobotoncontenido:

            if(puntoActual.contenedorAmarillo== false){
                plastico.setBackgroundResource(R.drawable.contenedordebasuraplfull);
                puntoActual.contenedorAmarillo= true;
            }else{
                plastico.setBackgroundResource(R.drawable.contenedordebasurapl);
                puntoActual.contenedorAmarillo=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.vidriobotoncontenido:

            if(puntoActual.contenedorVerde == false){
                vidrio.setBackgroundResource(R.drawable.contenedordebasuravfull);
                puntoActual.contenedorVerde = true;
            }else{
                vidrio.setBackgroundResource(R.drawable.contenedordebasurav);
                puntoActual.contenedorVerde=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.organicobotoncontenido:

            if(puntoActual.contenedorGris == false){
                organico.setBackgroundResource(R.drawable.contenedordebasuraf);
                puntoActual.contenedorGris = true;
            }else{
                organico.setBackgroundResource(R.drawable.contenedordebasura);
                puntoActual.contenedorGris=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.puntolimpiobotoncontenido:

            if(puntoActual.puntoLimpio == false){
                puntolimpio.setBackgroundResource(R.drawable.contenedordebasurafull);
                puntoActual.puntoLimpio = true;
            }else{
                puntolimpio.setBackgroundResource(R.drawable.contenedorpuntolimpio);
                puntoActual.puntoLimpio=false;
            }
        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.aceitebotoncontenido:
            if(puntoActual.contenedorNaranja == false){
                aceite.setBackgroundResource(R.drawable.contenedordebasuraacfull);
                puntoActual.contenedorNaranja = true;
            }else{
                aceite.setBackgroundResource(R.drawable.contenedordebasuraac);
                puntoActual.contenedorNaranja=false;
            }
        break;


            //Switch que anade puntoActual
            case R.id.anadircont:
                uploadFile();


                break;
            case R.id.cancelarid:
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);

                break;

        }

    }

        /*En este metodo introduce todo los campos a la base de datos.*/


    public void nuevocont(){

        /**
         * Metodo que crea el nuevo contenido terminando la sentencia de creacion de datos y cerrando la actividad
         */

        String uploadID=ref.push().getKey();
        System.out.println("La imagen antes de guardar en la BD es: " + puntoActual.getImagen());
        ref.child(uploadID).setValue(puntoActual);

        finish();


    }
    private String getFileExtension(Uri uri){

        ContentResolver cR=getContentResolver();
        MimeTypeMap mime =MimeTypeMap.getSingleton();


        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void captureImage(){
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST);


    }

    private void chooseImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }



    /**
     * *************************** Método que sube la imagen a Firebase Cloud Storage y el Punto de reciclaje actual a la BD de Firebase ****************************************
     * *************************** Guarda en el Punto de Reciclaje Actual la url de descarga de la imagen ***********************************************************************
     * */
    private void uploadFile(){

        if(filePath !=null){
            final StorageReference fileReference=storagereference.child(System.currentTimeMillis()+"."+getFileExtension(filePath));

            fileReference.putFile(filePath).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                    Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                    while(!uriTask.isComplete());
                    Uri downloadUrl = uriTask.getResult();

                    puntoActual.setImagen(downloadUrl.toString());
                    System.out.println("Despues de subir la imagen la url de descarga es: " + puntoActual.getImagen());
                    puntoActual.setImagen(downloadUrl.toString());

                    nuevocont();
                }
            });

        }else{
            Toast.makeText(this, "No hay archivos seleccionados", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode== PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() !=null){
            filePath =data.getData();
            Picasso.with(this).load(filePath).into(imagencontenedor);

        }

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imagencontenedor.setImageBitmap(photo);
        }
    }

    private String correccion(String campo){
        
        if(campo.equals("lugo")){
            provincia.setText("Lugo");
            campo= "Lugo";
            return campo;
        }
        if(campo.equals("pontevedra")){
            provincia.setText("Pontevedra");
            campo= "Pontevedra";
            return campo;
        }
        if(campo.equals("orense")){
            provincia.setText("Orense");
            campo= "Orense";
            return campo;
        }
        if(campo.equals("asturias")){
            provincia.setText("Asturias");
            campo= "Asturias";
            return campo;
        }

        if(campo.equals("cantabria")){
            provincia.setText("Cantabria");
            campo= "Cantabria";
            return campo;
        }

        if(campo.equals("albacete")){
            provincia.setText("Albacete");
            campo="Albacete";
            return campo;
        }

        if(campo.equals("alicante")){
            provincia.setText("Alicante");
            campo= "Alicante";
            return campo;
        }

        if(campo.equals("badajoz")){
            provincia.setText("Badajoz");
            campo= "Badajoz";
            return campo;
        }
        if(campo.equals("baleares")){
            provincia.setText("Baleares");
            campo= "Baleares";
            return campo;
        }
        if(campo.equals("barcelona")){
            provincia.setText("Barcelona");
            campo= "Barcelona";
            return campo;
        }
        if(campo.equals("burgos")){
            provincia.setText("Burgos");
            campo= "Burgos";
            return campo;
        }
        if(campo.equals("cantabria")){
            provincia.setText("Cantabria");
            campo= "Cantabria";
            return campo;
        }
        if(campo.equals("cuenca")){
            provincia.setText("Cuenca");
            campo= "Cuenca";
            return campo;
        }

        if(campo.equals("girona")){
            provincia.setText("Girona");
            campo= "Girona";
            return campo;
        }

        if(campo.equals("granada")){
            provincia.setText("Granada");
            campo= "Granada";
            return campo;
        }
        if(campo.equals("guadalajara")){
            provincia.setText("Guadalajara");
            campo="Guadalajara";
            return campo;
        }
        if(campo.equals("gipuzkoa")){
            provincia.setText("Gipuzkoa");
            campo="Gipuzkoa";
            return campo;
        }
        if(campo.equals("huelva")){
            provincia.setText("Huelva");
            campo= "Huelva";
            return campo;
        }
        if(campo.equals("huesca")){
            provincia.setText("Huesca");
            campo="Huesca";
            return campo;
        }
        if(campo.equals("madrid")){
            provincia.setText("Madrid");
            campo= "Madrid";
            return campo;
        }
        if(campo.equals("murcia")){
            provincia.setText("Murcia");
            campo= "Murcia";
            return campo;
        }
        if(campo.equals("navarra")){
            provincia.setText("Navarra");
            campo="Navarra";
            return campo;
        }
        if(campo.equals("ourense")){
            provincia.setText("Ourense");
            campo= "Ourense";
            return campo;
        }
        if(campo.equals("palencia")){
            provincia.setText("Palencia");
            campo= "Palencia";
            return campo;
        }
        if(campo.equals("salamanca")){
            provincia.setText("Salamanca");
            campo= "Salamanca";
            return campo;
        }
        if(campo.equals("segovia")){
            provincia.setText("Segovia");
            campo= "Segovia";
            return campo;
        }
        if(campo.equals("sevilla")){
            provincia.setText("Sevilla");
            campo= "Sevilla";
            return campo;
        }
        if(campo.equals("soria")){
            provincia.setText("Soria");
            campo= "Soria";
            return campo;
        }
        if(campo.equals("tarragona")){
            provincia.setText("Tarragona");
            campo= "Tarragona";
            return campo;
        }
        if(campo.equals("teruel")){
            provincia.setText("Teruel");
            campo= "Teruel";
            return campo;
        }
        if(campo.equals("toledo")){
            provincia.setText("Toledo");
            campo= "Toledo";
            return campo;
        }
        if(campo.equals("valencia")){
            provincia.setText("Valencia");
            campo= "Valencia";
            return campo;
        }
        if(campo.equals("valladolid")){
            provincia.setText("Valladolid");
            campo= "Valladolid";
            return campo;
        }
        if(campo.equals("vizcaya")){
            provincia.setText("Vizcaya");
            campo= "Vizcaya";
            return campo;
        }
        if(campo.equals("zamora")){
            provincia.setText("Zamora");
            campo= "Zamora";
            return campo;
        }
        if(campo.equals("zaragoza")){
            provincia.setText("Zaragoza");
            campo= "Zaragoza";
            return campo;
        }

        if(campo.equals("malaga") || campo.equals("Malaga") ||campo.equals("málaga")){
            provincia.setText("Málaga");
            campo= "Málaga";
            return campo;
        }

        if(campo.equals("la coruña") || campo.equals("La coruña") || campo.equals("la Coruña")){
            provincia.setText("La Coruña");
            campo= "La Coruña";
            return campo;
        }
        if(campo.equals("alava") || campo.equals("Alava")|| campo.equals("álava")){
            provincia.setText("Álava");
            campo= "Álava";
            return campo;
        }
        if(campo.equals("almeria") || campo.equals("Almeria")|| campo.equals("almería")){
            provincia.setText("Almería");
            campo= "Almería";
            return campo;
        }
        if(campo.equals("avila") || campo.equals("ávila")|| campo.equals("Avila")){
            provincia.setText("Ávila");
            campo= "Ávila";
            return campo;
        }
        if(campo.equals("caceres") || campo.equals("Caceres")|| campo.equals("cáceres")){
            provincia.setText("Cáceres");
            campo= "Cáceres";
            return campo;
        }
        if(campo.equals("cádiz") || campo.equals("cadiz")|| campo.equals("Cadiz")){
            provincia.setText("Cádiz");
            campo="Cádiz";
            return campo;
        }
        if(campo.equals("castellón") || campo.equals("Castellon")|| campo.equals("castellon")){
            provincia.setText("Castellón");
            campo= "Castellón";
            return campo;
        }
        if(campo.equals("Ciudad real") || campo.equals("ciudad Real")|| campo.equals("ciudad real")){
            provincia.setText("Ciudad Real");
            campo= "Ciudad Real";
            return campo;
        }
        if(campo.equals("Cordoba") || campo.equals("cordoba")|| campo.equals("córdoba")){
            provincia.setText("Córdoba");
            campo= "Córdoba";
            return campo;
        }
        if(campo.equals("jaén") || campo.equals("Jaen")|| campo.equals("jaen")){
            provincia.setText("Jaén");
            campo= "Jaén";
            return campo;
        }
        if(campo.equals("la rioja") || campo.equals("La rioja")|| campo.equals("la Rioja")){
            provincia.setText("La Rioja");
            campo= "La Rioja";
            return campo;
        }
        if(campo.equals("las Palmas") || campo.equals("Las palmas")|| campo.equals("las palmas")){
            provincia.setText("Las Palmas");
            campo= "Las Palmas";
            return campo;
        }
        if(campo.equals("Leon") || campo.equals("león")|| campo.equals("leon")){
            provincia.setText("León");
            campo= "León";
            return campo;
        }
        if(campo.equals("lérida") || campo.equals("Lerida")|| campo.equals("lerida")){
            provincia.setText("Lérida");
            campo= "Lérida";
            return campo;
        }
        
        if(campo.equals("santa Cruz de Tenerife") || campo.equals("Santa cruz de Tenerife")
                || campo.equals("Santa Cruz de tenerife") || campo.equals("santa cruz de Tenerife")
                || campo.equals("Santa cruz de tenerife")  || campo.equals("santa Cruz de tenerife")
                || campo.equals("santa cruz de tenerife")  ){
            provincia.setText("Santa Cruz de Tenerife");
            campo= "Santa Cruz de Tenerife";
            return campo;
        }
        
        return campo;
    }

    public static String mayusPrimer(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        } else {
            return str.substring(0, 1).toUpperCase() + str.substring(1);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text=parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}


